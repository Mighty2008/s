# Metronome
A Javascript metronome. Taken from the tutorial here: https://www.youtube.com/playlist?list=PLXAhCH9FJ8zU2lR4ZvJGianiyVJlqm0z0
